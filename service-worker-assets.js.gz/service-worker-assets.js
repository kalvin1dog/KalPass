self.assetsManifest = {
  "version": "Po4Wn1zW",
  "assets": [
    {
      "hash": "sha256-6Bi2oQLpLVVfIa4aHLb74d1FkZWL9fFElK4dfW9dQ6Y=",
      "url": "KalPassApp.styles.css"
    },
    {
      "hash": "sha256-ixr/5spq2LEQBxq27ljUYI5vfDERuTTRX5xw/pWfQoc=",
      "url": "_content/Microsoft.AspNetCore.Components.QuickGrid/Microsoft.AspNetCore.Components.QuickGrid.boiwgh0w5b.bundle.scp.css"
    },
    {
      "hash": "sha256-tnamWuQ2F5I2J8hbtBt4/9i8Mb2y2o+9Tepj5tUrSdU=",
      "url": "_content/Microsoft.AspNetCore.Components.QuickGrid/QuickGrid.razor.js"
    },
    {
      "hash": "sha256-LSjXqIrj4w+taoWhjtqlninsh7xRxj8hI6jjd3nwEhs=",
      "url": "_framework/KalPassApp.jg0m89qn56.wasm"
    },
    {
      "hash": "sha256-gDr+Dk9wJGwwXRNxqopQ3T3mplhuvSUuHOhJOxCO+fk=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.oagoiomv71.wasm"
    },
    {
      "hash": "sha256-L3Y0+Y3NSGVBues75MBmFLXpqv1Z8phF5ROqm4nbfig=",
      "url": "_framework/Microsoft.AspNetCore.Components.QuickGrid.3v9hubwlxh.wasm"
    },
    {
      "hash": "sha256-HE1V5ZXJgB/qNDhctE4Mg8k0m8FuRJykqeku9Y0xOyc=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.o7lme8f3yo.wasm"
    },
    {
      "hash": "sha256-DJmCbU2DnHb24x2LSDb6bSvqJEQCUeel5yPwY4ltoW4=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.c6t9nxlmk8.wasm"
    },
    {
      "hash": "sha256-RmYS0X3mbbCFHhWzWt1USJsf5Lti1TnJqpl+oC+rsvw=",
      "url": "_framework/Microsoft.AspNetCore.Components.ezski6m5jr.wasm"
    },
    {
      "hash": "sha256-3DH5Li3nbKgskNzRybjZBIfXSoxH/TN0wolg2KHl/YQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.w7skqr0zek.wasm"
    },
    {
      "hash": "sha256-D1jnvoQnv2aAi2ps5NzM3lqE5jEy+XJit2tS6neJnXM=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.dtdoolwb2w.wasm"
    },
    {
      "hash": "sha256-FU9TpGEmQwWgADUtlXFTdJIwsCDEyFtgEJacSi8iIoY=",
      "url": "_framework/Microsoft.Extensions.Configuration.jqj4k4pj3p.wasm"
    },
    {
      "hash": "sha256-le5rmrBMDRqKfFdTIfPXMMq+YRlD1okvk+xc6dLUYm8=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.7t9rn8l3bj.wasm"
    },
    {
      "hash": "sha256-Q4ElQAxHDkCjuYL0AruUm9A7KnOrFxMIBY0KelUF1W8=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.1rfo1y3yks.wasm"
    },
    {
      "hash": "sha256-E3T03PI0lTG4JbHWUNUrC7mQtfV5kTOE6iaW95IE7bw=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.ppxhzhi3nu.wasm"
    },
    {
      "hash": "sha256-DTNxE9CKAiPWTFDFl3niOH75tY1pweWfsMzIaVbhBMI=",
      "url": "_framework/Microsoft.Extensions.Logging.r2dra2oldd.wasm"
    },
    {
      "hash": "sha256-cm6fbI6Jvm2BgJS70FB2k3qbYAzuS5nCCXg8IXj7cdA=",
      "url": "_framework/Microsoft.Extensions.Options.u4muuiav6l.wasm"
    },
    {
      "hash": "sha256-7R0sWRhKvcSoQaFmMrrXBOS1v+DUjxhETvDxEQbHVRQ=",
      "url": "_framework/Microsoft.Extensions.Primitives.7za6xlrecu.wasm"
    },
    {
      "hash": "sha256-d1csL6xZFLtlvPbddYtpSayl19/drI7WubYTnTBYboc=",
      "url": "_framework/Microsoft.Extensions.Validation.zlafc2er9f.wasm"
    },
    {
      "hash": "sha256-wmWkUz8XauAbA+eb0N0RvClESqaj+ct9V3xtGILLnp8=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.mrus3axuke.wasm"
    },
    {
      "hash": "sha256-k/iZrGpieQGZLQH59A53VwtspFZji2KU++/y0h8tSfg=",
      "url": "_framework/Microsoft.JSInterop.tsyx5l4o03.wasm"
    },
    {
      "hash": "sha256-tgTWt61ctNPfZjc3DFIUqvrLdZPKJPxF1cqw9ppmPpI=",
      "url": "_framework/System.Collections.Concurrent.6ldqg9m8wg.wasm"
    },
    {
      "hash": "sha256-FOO3ZB8cUTGweNmQOZbfUeg9C8MdUROo4TbXEb2OGE4=",
      "url": "_framework/System.Collections.Immutable.c0mu6ffol7.wasm"
    },
    {
      "hash": "sha256-UsF1FPCgau/XQvu7ORzQTOBhh+J1TTZuHE1pY+xkm/E=",
      "url": "_framework/System.Collections.NonGeneric.6qg8sz779f.wasm"
    },
    {
      "hash": "sha256-JzVbtLmuCCPnnc1LUexIJ5qPM7Nn1Czue+ZDCGGNymU=",
      "url": "_framework/System.Collections.Specialized.p4njbhggv9.wasm"
    },
    {
      "hash": "sha256-fl+4yvm8MfJA5SQuwDeJm4lC5PEyF/k4ZzJTsYmxMes=",
      "url": "_framework/System.Collections.mi2jgjxil8.wasm"
    },
    {
      "hash": "sha256-+jXv5myZK7RDL3jISNBm3YS6BnYzTHWqFyv/ULjOWrc=",
      "url": "_framework/System.ComponentModel.6p3x58af60.wasm"
    },
    {
      "hash": "sha256-BodvzFmt64MVJUYT3TTi4t7FpMCcsZ6sZ0jyfIJDDSg=",
      "url": "_framework/System.ComponentModel.Annotations.mo9gaakkb5.wasm"
    },
    {
      "hash": "sha256-NNVq7gumjXjWdtOGbW6+mAiui44CVX1R7llvSqW4vYk=",
      "url": "_framework/System.ComponentModel.Primitives.cchodor2of.wasm"
    },
    {
      "hash": "sha256-alOO6OvY5SV+UI3t3zmUWA8ahh5QY8qdEHqiFJZNlLo=",
      "url": "_framework/System.ComponentModel.TypeConverter.2mxdsbk6f0.wasm"
    },
    {
      "hash": "sha256-5EFmdB6rdnYfcKfJujzQcX7lUCOjTZKO1LoG2FDkJVY=",
      "url": "_framework/System.Console.4o8s3lxnpt.wasm"
    },
    {
      "hash": "sha256-s/pVX8itpmtYN2Sv50GJkKk6VLrC8Gy/ore8Ki+T8Yw=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.n3zko97ftx.wasm"
    },
    {
      "hash": "sha256-5NlyiKMjQMJVLZ+E92VHzP4NXkvjJnT4LTZkWqm0KJc=",
      "url": "_framework/System.IO.Pipelines.orwcdf2bqi.wasm"
    },
    {
      "hash": "sha256-PaUhmc7dDBNNKkvcLiVm6KthFg0YKH4GTok0LXgSXJo=",
      "url": "_framework/System.Linq.Expressions.hzcma4ifig.wasm"
    },
    {
      "hash": "sha256-K+3gfVNzWCU1Lx5WLaMiRFaA1wmZ4GF9fvpsbjtQ2/g=",
      "url": "_framework/System.Linq.Queryable.rgtwgo28go.wasm"
    },
    {
      "hash": "sha256-DdxT8nf0+dDB8kKDLOEb/qr8SEzCtljkXkD4Ok4kUgY=",
      "url": "_framework/System.Linq.n7u89kidex.wasm"
    },
    {
      "hash": "sha256-BRU4Anh04FLb7m96aHkNrzect+SEGDmv8EuTMsl5ZBc=",
      "url": "_framework/System.Memory.botb82zsb1.wasm"
    },
    {
      "hash": "sha256-X6golN/AMKSC7GH+wRCHObEyUMVMRKjj1cGRVULVMlU=",
      "url": "_framework/System.Net.Http.Json.5vghsfrk65.wasm"
    },
    {
      "hash": "sha256-FkTubak5I2dSE1DhBjV4k76U4xsB8vSFgvvVIV4kXOM=",
      "url": "_framework/System.Net.Http.y509ffpdan.wasm"
    },
    {
      "hash": "sha256-RVkQ/jSGi5Krx6eFLwEIVlNuEjm57Ajp7YgPzB8P+jA=",
      "url": "_framework/System.Net.Primitives.nlzmlluvkx.wasm"
    },
    {
      "hash": "sha256-WyFL1/88A3WW+AWEZi4GuPG4Jp9MDIKjcsjCSv7ncC4=",
      "url": "_framework/System.ObjectModel.19eq01bnm5.wasm"
    },
    {
      "hash": "sha256-K8j6Hgx1P+LN3Jde2aoWrXNI73VBHdozYp4ygkMlubA=",
      "url": "_framework/System.Private.CoreLib.dudblm5msu.wasm"
    },
    {
      "hash": "sha256-Nt6EVO0kyVLdEX+tEBl0gIdVlHpSF6dOu1VeTZcDL+g=",
      "url": "_framework/System.Private.Uri.m19krr7kv1.wasm"
    },
    {
      "hash": "sha256-oDZnN5crzp1SC0PfFbAOYzqrzwZZWweW00tScdRtx+o=",
      "url": "_framework/System.Runtime.08we8hzqh2.wasm"
    },
    {
      "hash": "sha256-WAM5OMcJO64InQovrLZ46el9w7eLyMLnICLGedHyr8Q=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.ktbegkrd8y.wasm"
    },
    {
      "hash": "sha256-oAiqN4+0rXCP07gQh1D89o9s9TjaMTh1Pgbtm7wEiPg=",
      "url": "_framework/System.Security.Cryptography.ouxcxoa0xa.wasm"
    },
    {
      "hash": "sha256-WWGqU1P7ibS/e2CelqkoMZQa+FhxTzMT6kADSFv4tPw=",
      "url": "_framework/System.Text.Encodings.Web.7kxzi2zh06.wasm"
    },
    {
      "hash": "sha256-uHvdC+B/9H6sVnCcdkY6jpXmhUaaOeByK9z1KO2vpMk=",
      "url": "_framework/System.Text.Json.oswhkw7prm.wasm"
    },
    {
      "hash": "sha256-tsgoNz2G1SRS1L6dSo9nqiztUvGHKwUVS2sw660tr1I=",
      "url": "_framework/System.Text.RegularExpressions.azop2fezew.wasm"
    },
    {
      "hash": "sha256-JRSnUKU4RCZCvwQXVaK87jabHPSnQK1daxG24xvCico=",
      "url": "_framework/System.deed694j9w.wasm"
    },
    {
      "hash": "sha256-3lCWrko3zwspV40aQhs2S/IMkRSarnHRKIdkHhuXIBA=",
      "url": "_framework/blazor.webassembly.66stpp682q.js"
    },
    {
      "hash": "sha256-USf5HYNGPJcTyUkeCIzn7lVK8ockT3/orv0Q7FEuWNQ=",
      "url": "_framework/dotnet.dxqcg59la1.js"
    },
    {
      "hash": "sha256-tjie09uavTiX1TnkP9OL+OcnxCOs44ff5Dgws1rnAnc=",
      "url": "_framework/dotnet.native.2mv1pqdd2n.wasm"
    },
    {
      "hash": "sha256-JvdIvkSF0x6euoPT2QnQSMg2Gyv2oJbFeBi1XmWLYFU=",
      "url": "_framework/dotnet.native.69poregybn.js"
    },
    {
      "hash": "sha256-ArknccFM1sHNVcih0x1h52AG+abNCoQjl6BlVrv3ePw=",
      "url": "_framework/dotnet.runtime.q5rqv3xrhm.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-yRJ49z3y3rHi/X6jpbhaZS6+RJBCP3/2qRNriPwlJ3c=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-q/wIWoIhvHkLzGnzHWq3g6xFLzNdEJ1zCqygdOsiEZ8=",
      "url": "index.html"
    },
    {
      "hash": "sha256-Whd2akiqyf0d+e4fSf41JuNUHxnfByNu2PucdOH6O5k=",
      "url": "js/crypto.js"
    },
    {
      "hash": "sha256-okQMv1xiOzEtk1HL/UYmoKPil6+YaTRQYzowC+bIYAY=",
      "url": "js/crypto.published.js"
    },
    {
      "hash": "sha256-Yy5/hBqRmmU2MJ1TKwP2aXoTO6+OjzrLmJIsC2Wy4H8=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css"
    },
    {
      "hash": "sha256-xAT+n25FE5hvOjj2fG4YdOwr1bl4IlAJBNg6PbhLT2E=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css.map"
    },
    {
      "hash": "sha256-5nDHMGiyfZHl3UXePuhLDQR9ncPfBR1HJeZLXyJNV24=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css"
    },
    {
      "hash": "sha256-kgL+xwVmM8IOs15lnoHt9daR2LRMiBG/cYgUPcKQOY4=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css.map"
    },
    {
      "hash": "sha256-CZxoF8zjaLlyVkcvVCDlc8CeQR1w1RMrvgYx30cs8kM=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css"
    },
    {
      "hash": "sha256-/siQUA8yX830j+cL4amKHY3yBtn3n8z3Eg+VZ15f90k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css.map"
    },
    {
      "hash": "sha256-vMxTcvkC4Ly7LiAT3G8yEy9EpTr7Fge4SczWp07/p3k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css"
    },
    {
      "hash": "sha256-7GdOlw7U/wgyaeUtFmxPz5/MphdvVSPtVOOlTn9c33Q=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css.map"
    },
    {
      "hash": "sha256-lo9YI82OF03vojdu+XOR3+DRrLIpMhpzZNmHbM5CDMA=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css"
    },
    {
      "hash": "sha256-RXJ/QZiBfHXoPtXR2EgC+bFo2pe3GtbZO722RtiLGzQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css.map"
    },
    {
      "hash": "sha256-l8vt5oozv958eMd9TFsPAWgl9JJK9YKfbVSs8mchQ84=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css"
    },
    {
      "hash": "sha256-0eqVT62kqRLJh9oTqLeIH4UnQskqVjib8hl2fXxl4lg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css.map"
    },
    {
      "hash": "sha256-V8psnHoJS/MPlCXWwc/J3tGtp9c3gGFRmqsIQgpn+Gg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css"
    },
    {
      "hash": "sha256-OoQVwh7Arp7bVoK2ZiTx2S//KrnPrSPzPZ93CqCMhe8=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css.map"
    },
    {
      "hash": "sha256-/8jh8hcEMFKyS6goWqnNu7t3EzZPCGdQZgO6sCkI8tI=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css"
    },
    {
      "hash": "sha256-910zw+rMdcg0Ls48ATp65vEn8rd5HvPxOKm2x3/CBII=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css.map"
    },
    {
      "hash": "sha256-2BubgNUPlQSF/0wLFcRXQ/Yjzk9vsUbDAeK2QM+h+yo=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css"
    },
    {
      "hash": "sha256-Nfjrc4Ur9Fv2oBEswQWIyBnNDP99q+LhL+z9553O0cY=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css.map"
    },
    {
      "hash": "sha256-KyE9xbKO9CuYx0HXpIKgsWIvXkAfITtiQ172j26wmRs=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css"
    },
    {
      "hash": "sha256-rHDmip4JZzuaGOcSQ1QSQrIbG0Eb3Zja9whqSF1zYIU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css.map"
    },
    {
      "hash": "sha256-H6wkBbSwjua2veJoThJo4uy161jp+DOiZTloUlcZ6qQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css"
    },
    {
      "hash": "sha256-p0BVq5Ve/dohBIdfbrZsoQNu02JSsKh1g0wbyiQiUaU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css.map"
    },
    {
      "hash": "sha256-GAUum6FjwQ8HrXGaoFRnHTqQQLpljXGavT7mBX8E9qU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css"
    },
    {
      "hash": "sha256-o8XK32mcY/FfcOQ1D2HJvVuZ0YTXSURZDLXCK0fnQeA=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css.map"
    },
    {
      "hash": "sha256-GKEF18s44B5e0MolXAkpkqLiEbOVlKf6VyYr/G/E6pw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css"
    },
    {
      "hash": "sha256-KzNVR3p7UZGba94dnCtlc6jXjK5urSPiZ/eNnKTmDkw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css.map"
    },
    {
      "hash": "sha256-PI8n5gCcz9cQqQXm3PEtDuPG8qx9oFsFctPg0S5zb8g=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css"
    },
    {
      "hash": "sha256-8SM4U2NQpCLGTQLW5D/x3qSTwxVq2CP+GXYc3V1WwFs=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-j5E4XIj1p1kNnDi0x1teX9RXoh1/FNlPvCML9YmRh2Q=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css"
    },
    {
      "hash": "sha256-3bYWUiiVYMZfv2wq5JnXIsHlQKgSKs/VcRivgjgZ1ho=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css.map"
    },
    {
      "hash": "sha256-h5lE7Nm8SkeIpBHHYxN99spP3VuGFKl5NZgsocil7zk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css"
    },
    {
      "hash": "sha256-rTzXlnepcb/vgFAiB+U7ODQAfOlJLfM3gY6IU7eIANk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css.map"
    },
    {
      "hash": "sha256-oYBsZqRGnWBDCRaOqZF2xHdMmJRWromY/3G1qKFPP7k=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js"
    },
    {
      "hash": "sha256-vRXsGjZZ4kF0H3ABLy4B4uuZddZKUM/orEH3k6cKkNc=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js.map"
    },
    {
      "hash": "sha256-CDOy6cOibCWEdsRiZuaHf8dSGGJRYuBGC+mjoJimHGw=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-oCo5ugq8+eOsRgUliFrgIA4o0ZdzdtrVj/3KwMGztW0=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-wSje+jFb4FvCngfjjXCx8fbCMFlIKsrvbjoLzfjt+hE=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js"
    },
    {
      "hash": "sha256-62LNGjkgAlIrJKDD4c/kMreylUUjBpaJ6PG/F5+eTGQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js.map"
    },
    {
      "hash": "sha256-QZdFT1ZNdly4rmgUBtXmXFS9BU1FTa+sPe6h794sFRQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js"
    },
    {
      "hash": "sha256-vB+7gXyUMGMgzcjz89SB336Zs4mjsyC6sDp2O/sgWGs=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js.map"
    },
    {
      "hash": "sha256-Mgw0+GaBDWOrn09+kewyONLZ0RvPdlh9ukqGjtiXUE8=",
      "url": "lib/bootstrap/dist/js/bootstrap.js"
    },
    {
      "hash": "sha256-7K7+1AQ6Qc9kxN9VsDSL3VDa6iKymCW+KrqZCA6reYg=",
      "url": "lib/bootstrap/dist/js/bootstrap.js.map"
    },
    {
      "hash": "sha256-3gQJhtmj7YnV1fmtbVcnAV6eI4ws0Tr48bVZCThtCGQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js"
    },
    {
      "hash": "sha256-3E9HrlWABidNF/w7DswkngDdz1O4rxln9pt4TPIdB0k=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js.map"
    },
    {
      "hash": "sha256-k631zRkJh6KgJdDNcb8ICh+fzYon/H6YkQpKYdqrifQ=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-enKgCMkYmCpfEcmg6Annbmc40VZ/A6aYYSQjZfVn2cU=",
      "url": "sample-data/weather.json"
    }
  ]
};
